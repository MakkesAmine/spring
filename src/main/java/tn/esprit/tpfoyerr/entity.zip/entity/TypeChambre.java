package tn.esprit.tpfoyerr.entity;

public enum TypeChambre {
    SIMPLE,
    DOUBLE,
    TRIPLE;


}
