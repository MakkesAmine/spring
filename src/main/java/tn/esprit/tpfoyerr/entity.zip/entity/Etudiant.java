package tn.esprit.tpfoyerr.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.Set;


@Getter
@Setter

@NoArgsConstructor
@AllArgsConstructor
@Builder


@Entity


public class Etudiant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idEtudiant;


    private String nomEt;


    private String prenomEt;

    private long cin;

    private String ecole;

    private Date dateNaissance;


    @ManyToMany(mappedBy = "etudiants")
    private Set<Reservation> reservations;





}