package tn.esprit.tpfoyerr.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.*;

import java.util.Date;
import java.util.Set;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity

public class Reservation {

    @Id

    private String idReservation;

    private Date anneeUniversitaire;

    private boolean estValide;

    @ManyToMany
    private Set<Etudiant> etudiants;





}